package com.servlets.appola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppolaApplication.class, args);
	}

}
